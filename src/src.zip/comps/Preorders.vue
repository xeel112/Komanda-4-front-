<template>
  <div id="preorders"  class="mb-4">
    <div class="row mb-2">
      <div class="col-4">
        <h3>Предзаказы</h3>
      </div>
      <div class="col-8 pr-3" style="text-align: right;">
        <router-link to="/Catalog" class="show-all">Смотреть все</router-link>
      </div>
    </div>
    <div class="d-none d-md-flex row">
          <div class="col-3">
            <app-home-product :user="user"/>
          </div>
          <div class="col-3">
            <app-home-product :user="user"/>
          </div>
          <div class="col-3">
            <app-home-product :user="user"/>
          </div>
          <div class="col-3">
            <app-home-product :user="user"/>
          </div>
        </div>
        <div class="d-flex d-md-none row no-gutters" style="overflow-x: hidden;">
          <div class="col-12 home-product-tape">
            <div class="home-product">
              <app-home-product :user="user"/>
            </div>
            <div class="home-product">
              <app-home-product :user="user"/>
            </div>
            <div class="home-product">
              <app-home-product :user="user"/>
            </div>
            <div class="home-product">
              <app-home-product :user="user"/>
            </div>
          </div>
        </div>
  </div>
</template>

<script>
import HomeProduct from './Home-product.vue'

export default {
  /*name: 'app',*/

  data () {
    return {
      
    }
  },
  props: [
    'user'
  ],
  components: {
    'app-home-product': HomeProduct
  }
}
</script>

<style lang="scss" scoped>
$light: #fce5a1;
$dark: #373536;
.slider-view {
  overflow-x: hidden;
}

.show-all {
  font-size: 1.35rem;
  text-decoration: underline;
  color: $dark;
}

#slider-tape {
  width: 400%;
}
</style>
