<template>
  <div id="slider">
    <div class="row no-gutters">
      <div class="col-12 col-xl-10 offset-xl-1 slider-view">
        <div id="slider-tape">
          <img src="./../img/slide1.png" alt="">
          <img src="./../img/slide2.png" alt="">
          <img src="./../img/slide3.png" alt="">
          <img src="./../img/slide4.png" alt="">
        </div>
      </div>
      <div class="col-2 d-md-none"></div>
      <div class="col-8 col-md-4 col-xl-2"></div>
      <div class="col-2 d-md-none"></div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'app',

  data () {
    return {
      
    }
  }
}
</script>

<style lang="scss">
$light: #fce5a1;
$dark: #373536;
.slider-view {
  overflow-x: hidden;
}

#slider-tape {
  width: 400%;
}
</style>
